import express from "express";
import { createTask, deleteTask, editTask, getTasksByUserAndDate, updateTaskState } from "../controllers/taskController.js";
import { isVerifiedUser } from "../middlewares/tokenVerification.js";




const router = express.Router();

router.get("/tasks", isVerifiedUser, getTasksByUserAndDate);
router.delete("/tasks/:taskId", deleteTask);// passing as parameter
router.patch("/tasks/:taskId/state/:state", updateTaskState);
router.post("/tasks", createTask);
router.put("/tasks/:taskId", editTask);

export default router;